Hi <strong>{{ $name }}</strong>,
<br/>
Please find below Link to reset your Password:-
<br/>
<a href="http:4300/reset-password/<?php echo $token; ?>">Reset Password Link</a>