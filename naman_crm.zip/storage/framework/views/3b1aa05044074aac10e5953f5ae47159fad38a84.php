
 <!--header section start-->
 <?php if($pdfData): ?>
  <?php $__currentLoopData = $pdfData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <header>
	<div class="container">
		<div class="col-6">
			<h1>PRODUCT CATALOGUE</h1>
			<p>Status: <?php echo e($eachData['project_status']); ?> <br/>
			 Products available:  <?php echo e($eachData['project_avail_date']); ?> - <?php echo e($eachData['project_avail_end_date']); ?>

			</p>
		</div>
		
		<div class="col-6">
			<img src="<?php echo e(URL::asset('images/logo.png')); ?>">
		</div>
		
	</div>
 </header>
  <!--header section end-->
  
  <div class="home-section">
	<div class="container">
		<div class="left-home-section">
			<ul>
				<li><span> Conatct name: <?php echo e($eachData['project_mang_name']); ?> <br/>Email: <?php echo e($eachData['project_mang_email']); ?><br/>Phone: <?php echo e($eachData['project_mang_mobile']); ?></span> </li>
				<li><span><?php echo e($eachData['customer']['customer_name']); ?></span> </li>
				<li><span><?php echo e($eachData['project_name']); ?> <br/><?php echo e($eachData['project_address']); ?> </span> </li>
			</ul>
		 
		</div>
		
		<div class="right-home-section">
			<img height="900" src="https://resources-products-new.s3.ap-south-1.amazonaws.com/uploads/projects/<?php echo e($eachData['project_image']); ?>">
		</div>
	</div>
  </div>
  <div style="page-break-after:always">&nbsp;</div> 
	<div class="listing-section">
		<div class="container">
			<h3>PRODUCT CATALOGUE <img src="<?php echo e(URL::asset('images/logo.png')); ?>"></h3>
			<?php $__currentLoopData = $eachData['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$eachprod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-12">
					<div class="one">
						<img height="417" src="https://resources-products-new.s3.ap-south-1.amazonaws.com/uploads/products/<?php echo e($eachprod['product_image']); ?>">
					</div>
					<div class="two">
						<ul class="listing-ul">
							<li>
								<div><h5> <?php echo e($eachprod['product_name']); ?> </h5></div>
								<div><h5> BUILDING PART: <?php echo e($eachprod['building_part']); ?> </h5></div>
								<div><h5>PRODUCT ID .: <?php echo e($eachprod['product_id']); ?> </h5></div>
							</li>
							
							<li>
								<div>
									<h6>LOCATION IN BUILDING</h6>
									<span> <?php echo e($eachprod['location_building']); ?></span>
								</div>
								<div>
									<h6>DESCRIPTION </h6>
									<span> <?php echo e($eachprod['description']); ?></span>
								</div>
							</li>
							
							<li>
								<div>
									<h6>QUANTITY  </h6>
									<span><?php echo e($eachprod['quantity']); ?> <?php echo e($eachprod['unitqnt']); ?></span>
								</div>
								<div>
									<h6>MODEL DESCRIPTION </h6>
									<span><?php echo e($eachprod['product_info']); ?></span>
								</div>
							</li>
							
							<li>
								<div>
									<h6>DIMENSIONS  </h6>
									<span>L: <?php echo e($eachprod['length']); ?> <?php echo e($eachprod['unit']); ?><br/>W: <?php echo e($eachprod['width']); ?> <?php echo e($eachprod['unit']); ?> <br/>H: <?php echo e($eachprod['height']); ?> <?php echo e($eachprod['unit']); ?></span>
								</div>
								<div>
									<h6>POTENTIAL </h6>
									<span><?php echo e($eachprod['reuse']); ?></span>
								</div>
							</li>
							
							
							<li>
								<div>
									<h6>PRODUCT YEAR  </h6>
									<span><?php echo e($eachprod['production_year']); ?></span>
								</div>
								<div>
									<h6>EVALUVATION </h6>
									<span><?php echo e($eachprod['evaluvation']); ?></span>
								</div>
							</li>
							
							
							<li>
								<div>
									<h6>BRAND NAME </h6>
									<span><?php echo e($eachprod['brand_name']); ?></span>
								</div>
								<div>
									<h6>PRECONDITIONS FOR REUSE </h6>
									<span><?php echo e($eachprod['precondition']); ?></span>
								</div>
							</li>
							
							<li>
								<div>
									<h6>DOCUMENTATION </h6>
									<span><?php echo e(($eachprod['documentation'] == '1') ? "YES" : "NO"); ?></span>
								</div>
								<div>
									<h6>RECOMMENDATION </h6>
									<span><?php echo e($eachprod['recommendation']); ?></span>
								</div>
							</li>

						</ul>
						
					</div>
					
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
	<div style="page-break-after:always">&nbsp;</div> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?> 
<!-- 	
 </body>

</html> --><?php /**PATH /var/www/html/resources/views/pdf/catalog.blade.php ENDPATH**/ ?>