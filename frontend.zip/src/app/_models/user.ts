﻿export class User {
    id: number;
    name: string;
    email: string;
    role: number;
    client_id: number;
    client_name: string;
    token?: string;
}