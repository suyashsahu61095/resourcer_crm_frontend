import { PriceDelimiterPipe } from './price-delimiter.pipe';

describe('PriceDelimiterPipe', () => {
  it('create an instance', () => {
    const pipe = new PriceDelimiterPipe();
    expect(pipe).toBeTruthy();
  });
});
