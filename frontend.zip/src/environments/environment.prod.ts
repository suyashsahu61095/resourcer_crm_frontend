export const environment = {
    production: true,
       // apiUrl: 'http://127.0.0.1:8000/api',
       
    //     apiUrl: 'https://apiprod.digitsas.no/public/api',
    //    imgBucket:'https://d10rdxeixe5doh.cloudfront.net/uploads/products/documents/',
     



     apiUrl: 'https://api.digitsas.no/public/api',
       imgBucket:' https://d38b2gpjikxyz1.cloudfront.net/uploads/products/documents/',

       
};
